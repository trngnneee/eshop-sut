# BUG-FR02-A-12: Không có nút Toggle ẩn/hiện mật khẩu trên biểu mẫu

| Tên trường (Field) | Giá trị (Value) |
| :--- | :--- |
| **No.** | 12 |
| **BugID** | `BUG-FR02-A-12` |
| **Status** | **Open** |
| **Requirement Name** | FR-22 Form Requirements |
| **Summary** | Người dùng không thể tự chọn ẩn hay hiện mật khẩu để kiểm tra vì thiếu hoàn toàn nút/icon toggle ẩn hiện. |
| **Steps to reproduce** | 1. Xem ô nhập mật khẩu trên trang đăng nhập `/login`.<br>2. Không có bất kỳ nút "Hiện" hay "Ẩn" nào kế bên. |
| **Severity** | Cosmetic |
| **Frequency** | Always |
| **Priority** | Low |
| **Evidence (Screenshot)** | ![Screenshot](evidences/BUG-FR02-A-12.png) |
| **Date** | 2026-06-23 |
| **Reporter** | Khoa |
