# BÁO CÁO KIỂM THỬ - MINI LAB DATABASE TESTING

## Tổng quan

- Môi trường: Node.js + SQLite (in-memory) · Jest + Supertest · @faker-js/faker
- Lệnh chạy: `npx jest --verbose` (từ thư mục `tests/databases_testing/`)
- **Tổng số test case: 15**
- **Số lượng Pass: 10**
- **Số lượng Fail (phát hiện bug): 5** — toàn bộ là test fail **có chủ đích**, dùng để chứng minh 4 bug ẩn trong starter kit.

| # | Test case | Kết quả | Ghi chú |
|---|-----------|---------|---------|
| 1 | Referential Integrity: orphan record sau khi xóa user | ❌ FAIL | Bằng chứng BUG-03 |
| 2 | Referential Integrity: orphan record sau khi xóa coupon | ❌ FAIL | Bằng chứng BUG-03 |
| 3 | Unique Constraint: không cho phép trùng code coupon | ✅ PASS | `SQLITE_CONSTRAINT` |
| 4 | Unique Constraint: không cho phép trùng email user | ✅ PASS | `SQLITE_CONSTRAINT` |
| 5 | Data Type Consistency: price luôn phải là number | ❌ FAIL | Bằng chứng BUG-04 |
| 6 | Case 1 (Valid): CP_PERCENT giảm đúng 10% cho đơn 200 | ❌ FAIL | Bằng chứng BUG-01 |
| 7 | Case 2 (Below Min): đơn chưa đạt min_order_amount | ✅ PASS | 400 đúng |
| 8 | Case 3 (Expired): coupon đã hết hạn | ✅ PASS | 400 đúng |
| 9 | Case 3b (Inactive): coupon bị khóa | ✅ PASS | 400 đúng |
| 10 | Case 4 (Max Usage): user đã dùng hết lượt | ✅ PASS | 400 đúng |
| 11 | Case 5 (Fixed): CP_FIXED giảm đúng 15 | ✅ PASS | Nhánh `fixed` đúng |
| 12 | Valid: pending → confirmed → shipping → delivered | ✅ PASS | State machine đúng chiều xuôi |
| 13 | Invalid: pending → delivered (nhảy cóc) | ✅ PASS | 400 đúng |
| 14 | Invalid: canceled → delivered phải bị chặn | ❌ FAIL | Bằng chứng BUG-02 |
| 15 | 404 khi order không tồn tại | ✅ PASS | |

## Danh sách Bug phát hiện

### BUG-01: Sai công thức tính giảm giá theo phần trăm
- **Mức độ:** Cao (High)
- **Vị trí:** `app.js` — `POST /api/apply-coupon` (nhánh `discount_type === 'percent'`)
- **Mô tả:** Code dùng `discount_amount = total_amount * (1 - coupon.discount_value)`. Với đơn 200 và `discount_value = 0.10` (10%), số tiền giảm đúng phải là **20** và final amount là **180**; code hiện tại trả về discount = **180**, final = **20** — tức khách được giảm 90% thay vì 10%.
- **Root cause:** Nhầm giữa "số tiền giảm" và "số tiền còn lại phải trả". `total * (1 - v)` là số tiền còn lại, không phải số tiền được giảm.
- **Bằng chứng:** Test #6 — `Case 1 (Valid): CP_PERCENT giảm đúng 10% cho đơn 200`:
  ```
  Expected: 20
  Received: 180
  ```
- **Đề xuất sửa:**
  ```javascript
  // discount_value lưu dạng tỉ lệ (0.10 = 10%)
  discount_amount = total_amount * coupon.discount_value;
  // (nếu quy ước lưu 10 thay vì 0.10 thì dùng: total_amount * (coupon.discount_value / 100))
  ```
- **Tác động:** Sai lệch doanh thu nghiêm trọng — mọi đơn dùng coupon phần trăm bị tính gần như miễn phí.

### BUG-02: Cho phép chuyển trạng thái canceled → delivered
- **Mức độ:** Cao (High)
- **Vị trí:** `app.js` — `PUT /api/admin/orders/:id/status`
- **Mô tả:** `canceled` là terminal state nhưng code có nhánh cho phép `canceled → delivered` (trả 200 và cập nhật DB). Đơn đã hủy có thể "sống lại" thành đã giao.
- **Root cause:** Nhánh điều kiện thừa được thêm vào bảng transition:
  ```javascript
  // LỖI: đơn đã hủy lại được phép thành Delivered!
  if (currentStatus === 'canceled' && status === 'delivered')
    isValidTransition = true;
  ```
- **Bằng chứng:** Test #14 — `Invalid: canceled -> delivered phải bị chặn`:
  ```
  Expected: 400
  Received: 200
  ```
- **Đề xuất sửa:** Xóa nhánh trên. Bền vững hơn, khai báo state machine dưới dạng bảng:
  ```javascript
  const VALID_TRANSITIONS = {
    pending:   ['confirmed', 'canceled'],
    confirmed: ['shipping', 'canceled'],
    shipping:  ['delivered'],
    delivered: [],   // terminal
    canceled:  [],   // terminal
  };
  const isValidTransition = (VALID_TRANSITIONS[currentStatus] || []).includes(status);
  ```
- **Tác động:** Sai dữ liệu thống kê bán hàng; nguy cơ giao hàng/thanh toán/hoàn tiền sai cho đơn đã hủy.

### BUG-03: Thiếu Foreign Key trong coupon_usage (orphan record)
- **Mức độ:** Trung bình (Medium)
- **Vị trí:** Database schema — bảng `coupon_usage`
- **Mô tả:** `coupon_usage.coupon_id` và `coupon_usage.user_id` không khai báo FOREIGN KEY. Khi xóa user 1 (hoặc coupon 5), bản ghi con trong `coupon_usage` vẫn tồn tại → **orphan record** (data anomaly).
- **Bằng chứng:** Test #1 và #2 — sau `DELETE FROM users WHERE id = 1`, truy vấn `SELECT * FROM coupon_usage WHERE user_id = 1` vẫn trả về 1 dòng:
  ```
  Expected: 0
  Received: 1
  ```
- **Đề xuất sửa:**
  ```sql
  CREATE TABLE coupon_usage (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    coupon_id INTEGER,
    user_id INTEGER,
    used_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (coupon_id) REFERENCES coupons(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
  ```
  Lưu ý SQLite: phải bật FK cho **mỗi** connection, nếu không FK bị bỏ qua:
  ```javascript
  db.run('PRAGMA foreign_keys = ON');
  ```
- **Tác động:** Dữ liệu rác tích tụ; đếm lượt dùng coupon (`COUNT(*)` trong apply-coupon) có thể dựa trên bản ghi mồ côi → từ chối/duyệt sai.

### BUG-04: API trả sai kiểu dữ liệu price
- **Mức độ:** Trung bình (Medium)
- **Vị trí:** `app.js` — `GET /api/products/:id`
- **Mô tả:** Với sản phẩm có ID chẵn, API ép `row.price = row.price.toString()` → response trả `price` là `string` thay vì `number`, phá vỡ data contract của API.
- **Bằng chứng:** Test #5 — lặp qua ID 1→5, fail tại ID 2:
  ```
  Expected: "number"
  Received: "string"
  ```
- **Đề xuất sửa:** Xóa dòng ép kiểu:
  ```javascript
  // XÓA: if (row.id % 2 === 0) row.price = row.price.toString();
  res.json(row);
  ```
- **Tác động:** Client tính toán trên string (`"100" * 1.1`, cộng chuỗi…) gây lỗi ngầm ở frontend web/mobile; bug chỉ lộ ra ở một nửa số sản phẩm nên rất khó phát hiện bằng test thủ công.

## Ghi chú kỹ thuật khi chạy test (bài học thực tế)

- **Test Isolation:** `setupTestDB()` được gọi trong `beforeEach` — mỗi test chạy trên cùng một trạng thái DB chuẩn (5 coupon biên, order 1 `pending`, order 2 `canceled`, user 1 đã dùng hết lượt CP_MAX_REACHED). Test #12 thay đổi trạng thái order 1 nhưng không ảnh hưởng test #13 nhờ setup lại.
- **Không throw trong callback native của sqlite3:** phiên bản đầu của test đặt `expect()` trực tiếp trong callback `db.run`/`db.all` (kiểu `done`). Khi assertion fail, exception bị throw xuyên qua tầng native của `node_sqlite3` làm hỏng statement queue → toàn bộ test sau đó bị treo (timeout hook) và crash `napi_throw` khi thoát. Giải pháp: promisify (`dbRun`/`dbAll`) để assertion nằm ngoài callback native.

## Kết luận

Starter kit thể hiện đúng thông điệp của bài lab: **các bug nghiêm trọng nhất không nằm ở happy path**. Cả 4 bug chỉ lộ ra khi kiểm thử giá trị biên (công thức phần trăm với số liệu tính tay), trạng thái bất thường (đơn đã hủy), dữ liệu "xấu" (xóa bản ghi cha), hoặc quét nhiều điểm dữ liệu (ID chẵn/lẻ).

Khuyến nghị cải tiến:
1. Đưa toàn bộ constraint vào schema (FK + `PRAGMA foreign_keys = ON`, CHECK cho `discount_type`, `status`) thay vì chỉ dựa vào validate ở tầng ứng dụng.
2. Khai báo state machine đơn hàng dạng bảng dữ liệu (transition map) để tránh nhánh if rời rạc dễ sai.
3. Thêm test data-contract (kiểu dữ liệu response) vào CI để chặn regression kiểu `price` string.
4. Chuẩn hóa quy ước `discount_value` (tỉ lệ 0.10 hay phần trăm 10) và ghi rõ trong tài liệu API — đây là gốc rễ khiến công thức dễ bị viết sai.
